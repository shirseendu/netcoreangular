using System;
using MySql.Data.MySqlClient;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Threading.Tasks;

namespace Apis
{
    public class Firsttbl
    {
        public int id { get; set; }
        public string name { get; set; }
        private MusicStoreContext Db { get; }

        public Firsttbl(MusicStoreContext db)
        {
            Db = db;
        } 

        public async Task<List<Firsttbl>> LatestPostsAsync()
        {
            using var cmd = Db.Connection.CreateCommand();
            cmd.CommandText = @"SELECT `id`, `name` FROM `firsttable` ORDER BY `Id` DESC LIMIT 10;";
            return await ReadAllAsync(await cmd.ExecuteReaderAsync());
        }

        ////https://mysqlconnector.net/tutorials/net-core-mvc/
        private async Task<List<Firsttbl>> ReadAllAsync(DbDataReader reader)
        {
            var posts = new List<Firsttbl>();
            using (reader)
            {
                while (await reader.ReadAsync())
                {
                    var post = new Firsttbl(Db)
                    {
                        id = reader.GetInt32(0),
                        name = reader.GetString(1)

                    };
                    posts.Add(post);
                }
            }
            return posts;
        }
    }

    public class MusicStoreContext : IDisposable
    {
        public MySqlConnection Connection { get; }

        public MusicStoreContext(string connectionString)
        {
            Connection = new MySqlConnection(connectionString);
        }

        public MySqlConnection GetConnection()
        {
            return this.Connection;
        }
        public void Dispose() => Connection.Dispose();
    }
}