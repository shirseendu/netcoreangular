﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using MySql.Data.MySqlClient;
using System.Configuration;
using Microsoft.Extensions.Configuration;
namespace Apis.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class DbtestController : ControllerBase
    {
        private static readonly string[] Summaries = new[]
        {
            "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
        };

        
        
        public MusicStoreContext Db { get; }
        // public DbtestController(ILogger<WeatherForecastController> logger)
        // {
        //     _logger = logger;
        // }
        public DbtestController(MusicStoreContext db)
        {
            Db = db;
        }
        [HttpGet]
      
        public async Task<IActionResult> Get()
        {
            await Db.Connection.OpenAsync();
            var query = new Firsttbl(Db);
            var result = await query.LatestPostsAsync();
            return new OkObjectResult(result);

        }
    }


}
